namespace PersonalRegister1;
public interface ITaxStrategy
{
    decimal EmployerTaxRate { get; }
}
public sealed class DayShiftTaxStrategy : ITaxStrategy
{
    public decimal EmployerTaxRate => 0.3142m; // example
}
public sealed class NightShiftTaxStrategy : ITaxStrategy
{
    public decimal EmployerTaxRate => 0.3542m; // higher for night shift example
}
