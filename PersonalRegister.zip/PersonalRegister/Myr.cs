namespace PersonalRegister1;
public abstract class Myr : IStamped
{
    public int Id { get; set; }
    public string Namn { get; set; } = "";
    public int Ålder { get; set; }
    public string Skift { get; protected set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsAlive { get; set; } = true;
    public DateTime LastLoadedAt { get; set; } = DateTime.UtcNow;

    protected Myr(int id, string namn, string skift, int ålder)
    {
        Id = id; Namn = namn; Skift = skift; Ålder = ålder;
    }
    public virtual string VisaInfo() => $"#{Id} {Namn} ({Ålder} år) – {Skift}-skift – Alive: {IsAlive}";
    public abstract ITaxStrategy TaxStrategy { get; }
}

public sealed class DagMyr : Myr
{
    public DagMyr(int id, string namn, int ålder) : base(id, namn, "Dag", ålder) {}
    public override ITaxStrategy TaxStrategy => new DayShiftTaxStrategy();
}

public sealed class NattMyr : Myr
{
    public NattMyr(int id, string namn, int ålder) : base(id, namn, "Natt", ålder) {}
    public override ITaxStrategy TaxStrategy => new NightShiftTaxStrategy();
}
