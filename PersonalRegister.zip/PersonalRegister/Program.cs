using PersonalRegister1;

Console.OutputEncoding = System.Text.Encoding.UTF8;

var register = PersonalRegister.GetInstance();
bool running = true;

while (running)
{
    Console.WriteLine("\n--- PERSONALREGISTER FÖR ARBETSMYROR ---");
    Console.WriteLine("1. Lägg till myra");
    Console.WriteLine("2. Visa alla myror");
    Console.WriteLine("3. Ta bort myra");
    Console.WriteLine("4. Uppdatera myra");
    Console.WriteLine("5. Sök myra");
    Console.WriteLine("6. Simulera en vecka");
    Console.WriteLine("7. Spara");
    Console.WriteLine("8. Ladda");
    Console.WriteLine("9. Avsluta");
    Console.Write("Välj: ");
    var choice = Console.ReadLine();

    switch (choice)
    {
        case "1": register.AddMyr(); break;
        case "2": register.ShowAll(); break;
        case "3": register.RemoveMyr(); break;
        case "4": register.UpdateMyr(); break;
        case "5": register.SearchMyr(); break;
        case "6": register.SimulateWeek(); break;
        case "7": register.Save(); break;
        case "8": register.Load(); break;
        case "9": running = false; Console.WriteLine("Avslutar..."); break;
        default: Console.WriteLine("Fel val, försök igen!"); break;
    }
}
