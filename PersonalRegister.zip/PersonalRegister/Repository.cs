using System.Text.Json;
using System.Text.Json.Serialization;

namespace PersonalRegister1;

public interface IMyrRepository
{
    List<Myr> LoadAll();
    void SaveAll(IEnumerable<Myr> all);
}

public sealed class JsonMyrRepository : IMyrRepository
{
    private readonly string _path;
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        Converters = { new MyrConverter() }
    };

    public JsonMyrRepository(string path) => _path = path;

    public List<Myr> LoadAll()
    {
        if (!File.Exists(_path)) return new List<Myr>();
        var json = File.ReadAllText(_path);
        var list = JsonSerializer.Deserialize<List<Myr>>(json, Options) ?? new();
        var now = DateTime.UtcNow;
        foreach (var m in list) m.LastLoadedAt = now;
        return list;
    }

    public void SaveAll(IEnumerable<Myr> all)
    {
        var json = JsonSerializer.Serialize(all, Options);
        File.WriteAllText(_path, json);
    }

    private sealed class MyrConverter : JsonConverter<Myr>
    {
        public override Myr? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            using var doc = JsonDocument.ParseValue(ref reader);
            var root = doc.RootElement;
            var kind = root.GetProperty("Skift").GetString()?.ToLower();
            int id = root.GetProperty("Id").GetInt32();
            string namn = root.GetProperty("Namn").GetString() ?? "";
            int ålder = root.GetProperty("Ålder").GetInt32();

            Myr m = kind == "natt" ? new NattMyr(id, namn, ålder) : new DagMyr(id, namn, ålder);
            m.CreatedAt = root.GetProperty("CreatedAt").GetDateTime();
            m.IsAlive = root.GetProperty("IsAlive").GetBoolean();
            if (root.TryGetProperty("LastLoadedAt", out var ll)) m.LastLoadedAt = ll.GetDateTime();
            return m;
        }

        public override void Write(Utf8JsonWriter writer, Myr value, JsonSerializerOptions options)
        {
            writer.WriteStartObject();
            writer.WriteNumber(nameof(Myr.Id), value.Id);
            writer.WriteString(nameof(Myr.Namn), value.Namn);
            writer.WriteNumber("Ålder", value.Ålder);
            writer.WriteString(nameof(Myr.Skift), value.Skift);
            writer.WriteString(nameof(Myr.CreatedAt), value.CreatedAt);
            writer.WriteBoolean(nameof(Myr.IsAlive), value.IsAlive);
            writer.WriteString(nameof(Myr.LastLoadedAt), value.LastLoadedAt);
            writer.WriteEndObject();
        }
    }
}
