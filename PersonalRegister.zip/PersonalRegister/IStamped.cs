namespace PersonalRegister1;
public interface IStamped
{
    DateTime LastLoadedAt { get; set; }
}
