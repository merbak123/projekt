1000m166using System.Collections.Concurrent;

namespace PersonalRegister1;

public sealed class PersonalRegister : IPersonalOperations
{
    private static PersonalRegister? _instance;
    public static PersonalRegister GetInstance() => _instance ??= new PersonalRegister();

    private readonly List<Myr> _all = new();
    private readonly Dictionary<int, Myr> _byId = new();
    private readonly IMyrRepository _repo;
    private int _nextId = 1;

    private PersonalRegister()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "myror.json");
        _repo = new JsonMyrRepository(path);
        Load(); // load on startup
        if (_all.Count > 0) _nextId = _all.Max(m => m.Id) + 1;
    }

    public void AddMyr()
    {
        Console.Write("Namn: ");
        var namn = Console.ReadLine() ?? "";
        Console.Write("Ålder: ");
        if (!int.TryParse(Console.ReadLine(), out var ålder)) { Console.WriteLine("Fel ålder."); return; }
        Console.Write("Skift (dag/natt): ");
        var skift = (Console.ReadLine() ?? "").ToLower();

        try
        {
            var myr = MyrFactory.Create(skift, _nextId++, namn, ålder);
            _all.Add(myr); _byId[myr.Id] = myr;
            Console.WriteLine("✅ Myra tillagd: " + myr.VisaInfo());
        }
        catch (Exception ex) { Console.WriteLine("Fel: " + ex.Message); }
    }

    public void ShowAll()
    {
        if (_all.Count == 0) { Console.WriteLine("(tomt)"); return; }
        foreach (var m in _all.OrderBy(m => m.Id))
            Console.WriteLine(m.VisaInfo());
    }

    public void RemoveMyr()
    {
        if (!TryGetId("ID att ta bort: ", out var id)) return;
        if (_byId.Remove(id, out var m))
        {
            _all.Remove(m);
            Console.WriteLine("🗑️  Tog bort " + m.VisaInfo());
        }
        else Console.WriteLine("Hittade ingen med ID " + id);
    }

    public void SearchMyr()
    {
        Console.Write("Sök (namn delsträng): ");
        var key = (Console.ReadLine() ?? "").Trim().ToLower();
        var res = _all.Where(m => m.Namn.ToLower().Contains(key)).OrderBy(m => m.Id).ToList();
        if (res.Count == 0) Console.WriteLine("Inga träffar.");
        else foreach (var m in res) Console.WriteLine(m.VisaInfo());
    }

    public void UpdateMyr()
    {
        if (!TryGetId("ID att uppdatera: ", out var id)) return;
        if (!_byId.TryGetValue(id, out var m)) { Console.WriteLine("Hittar ej."); return; }

        Console.Write($"Nytt namn ({m.Namn}): ");
        var namn = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(namn)) m.Namn = namn.Trim();

        Console.Write($"Ny ålder ({m.Ålder}): ");
        var ålderStr = Console.ReadLine();
        if (int.TryParse(ålderStr, out var å)) m.Ålder = å;

        Console.Write($"Nytt skift ({m.Skift}) [dag/natt]: ");
        var skift = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(skift))
        {
            var s = skift.Trim().ToLower();
            if (s is "dag" or "natt")
            {
                // recreate via factory to ensure correct subclass
                var ny = MyrFactory.Create(s, m.Id, m.Namn, m.Ålder);
                ny.CreatedAt = m.CreatedAt; ny.IsAlive = m.IsAlive; ny.LastLoadedAt = m.LastLoadedAt;
                _all[_all.IndexOf(m)] = ny; _byId[m.Id] = ny; m = ny;
            }
        }
        Console.WriteLine("✅ Uppdaterad: " + m.VisaInfo());
    }

    public void SimulateWeek()
    {
        // Add new ants (more born than die): create N new ants
        var rng = Random.Shared;
        int toAdd = Math.Max(3, _all.Count / 50); // ~2% growth minimum 3
        for (int i = 0; i < toAdd; i++)
        {
            var namn = "M" + _nextId.ToString("D5");
            var ålder = rng.Next(1, 5);
            var skift = rng.Next(0,2) == 0 ? "dag" : "natt";
            var myr = MyrFactory.Create(skift, _nextId++, namn, ålder);
            _all.Add(myr); _byId[myr.Id] = myr;
        }

        // Kill ants older than 2 weeks since CreatedAt
        var now = DateTime.UtcNow;
        int died = 0;
        foreach (var m in _all)
        {
            if (m.IsAlive && now - m.CreatedAt >= TimeSpan.FromDays(14))
            {
                m.IsAlive = false; died++;
            }
        }

        // Simple weekly employer tax report to demonstrate strategy
        decimal totalTax = 0m;
        foreach (var m in _all.Where(x=>x.IsAlive))
        {
            // assume a nominal weekly wage base to illustrate difference
            decimal baseWage = 1000m;
            totalTax += baseWage * m.TaxStrategy.EmployerTaxRate;
        }

        Console.WriteLine($"📅 Vecka simulerad. Nya: {toAdd}, Döda (>=14 dagar): {died}, Aktiva: {_all.Count(x=>x.IsAlive)}");
        Console.WriteLine($"💼 Beräknad arbetsgivaravgift denna vecka (simulerad): {totalTax:0.00}");
    }

    public void Save()
    {
        _repo.SaveAll(_all);
        Console.WriteLine("💾 Sparat.");
    }

    public void Load()
    {
        _all.Clear(); _byId.Clear();
        foreach (var m in _repo.LoadAll())
        {
            _all.Add(m); _byId[m.Id] = m;
        }
        Console.WriteLine($"📂 Läste in: {_all.Count} myror.");
    }

    private bool TryGetId(string prompt, out int id)
    {
        Console.Write(prompt);
        return int.TryParse(Console.ReadLine(), out id);
    }
}
