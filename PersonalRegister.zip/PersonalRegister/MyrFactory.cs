namespace PersonalRegister1;
public static class MyrFactory
{
    public static Myr Create(string skift, int id, string namn, int ålder)
    {
        return skift.Trim().ToLower() switch
        {
            "dag" => new DagMyr(id, namn, ålder),
            "natt" => new NattMyr(id, namn, ålder),
            _ => throw new ArgumentException("Skift måste vara 'dag' eller 'natt'")
        };
    }
}
