namespace PersonalRegister1;
public interface IPersonalOperations
{
    void AddMyr();
    void ShowAll();
    void RemoveMyr();
    void SearchMyr();
    void UpdateMyr();
    void SimulateWeek();
    void Save();
    void Load();
}
